const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');


const games = [
    { name: 'Mobile Legends', image: '../ml/logo ml.jpg', url: '../ml/ml.html' },
    { name: 'PUBG', image: 'pubg.png', url: 'pubg.html' },
    { name: 'Genshin Impact', image: 'images.jpeg', url: 'genshin.html' }
    // Tambahkan game lainnya sesuai kebutuhan
];

// Fungsi untuk menampilkan hasil pencarian
function showSearchResults(results) {
    // Bersihkan hasil sebelumnya
    searchResults.innerHTML = '';

    // Jika hasil pencarian kosong, sembunyikan searchResults
    if (results.length === 0) {
        searchResults.style.display = 'none';
        return;
    }

    // Buat elemen untuk setiap hasil pencarian
    results.forEach(game => {
        const gameElement = document.createElement('div');
        gameElement.classList.add('search-result');

        // Tambahkan gambar dan nama game
        const image = document.createElement('img');
        image.src = game.image;
        image.alt = game.name;
        gameElement.appendChild(image);

        const name = document.createElement('p');
        name.textContent = game.name;
        gameElement.appendChild(name);

        // Tambahkan event listener untuk mengarahkan ke halaman game saat di klik
        gameElement.addEventListener('click', () => {
            window.location.href = game.url;
        });

        searchResults.appendChild(gameElement);
    });

    // Tampilkan searchResults setelah selesai membangun hasil pencarian
    searchResults.style.display = 'block';
}

// Event listener untuk input pencarian
searchInput.addEventListener('input', () => {
    const query = searchInput.value.toLowerCase();
    const filteredGames = games.filter(game =>
        game.name.toLowerCase().includes(query)
    );
    showSearchResults(filteredGames);
});

// Sembunyikan searchResults saat halaman dimuat
searchResults.style.display = 'none';