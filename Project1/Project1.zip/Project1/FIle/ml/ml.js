function selectCategory(element) {
    var items = document.getElementsByClassName('category-item');
    for (var i = 0; i < items.length; i++) {
        items[i].classList.remove('active');
    }
    element.classList.add('active');
}
